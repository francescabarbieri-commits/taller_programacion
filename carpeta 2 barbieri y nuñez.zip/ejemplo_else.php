<?php
//ej 1
    $cantidad= 9 ;
    if ($cantidad<5){
        $total=$cantidad * 800 ;
    }else{ 
        $total=$cantidad*700;
}
echo "El total a pagar es de $ ".  $total ;


//ej 2
$calificación_1=7;
$calificación_2= 8;
$calificación_3 =10;

$promedio = ($calificación_1 + $calificación_2 + $calificación_3)/3 ;

if ($promedio >=7){
    echo "Estudiante aprobado con calificación: " .$promedio ;
    }else { 
    echo "Estudiante reprobado con calificación: " .$promedio;
}
