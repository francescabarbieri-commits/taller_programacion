<?php

//ej 1
echo 1=="1";

//ej 2
var_dump(2=="1");

//ej 3
$valor_1=2;
var_dump($valor_1=="1");

//4
$valor_1=1;
var_dump($valor_1==="1");

//5
$valor_1=7;
var_dump($valor_1!="7");

//6
$valor_1=9;
var_dump($valor_1<>"7");

//7
$valor_1="Hola";
var_dump($valor_1<>"7");

//8
$valor_1="Hola";
var_dump($valor_1=="Hola");

//9
$valor_1=2;
var_dump($valor_1!=="2");


//10
$valor_1=7;
var_dump($valor_1<2);

//11
$valor_1=3;
var_dump($valor_1<=2);

//12
$valor_1=3;
var_dump($valor_1>=2);



