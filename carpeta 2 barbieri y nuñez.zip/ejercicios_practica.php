<?php

//Ej 1 
$num1=15 ;
$num2=4 ;

$resultado= $num1 + $num2 ;

$resultado.= " ";
echo $resultado ;

$resto=$num1%$num2 ;
echo $resto ;

//Ej 2

$Byte=1024;
$kilobyte=1;

$potencia= $Byte * $kilobyte ;
echo " Un Kilobyte es igual a ", $potencia, " bytes" ;

//Ej 3

$script= "Sumar 10 más 5, y a ese resultado multiplicarlo por 3 ";

$resultado= ["resultado"=>(10+5)*3];

echo $script;
echo $resultado="resultado ";


//Ej 4

$puntaje=100 ;
$puntaje+=50 ;

echo $puntaje;

//Ej 5

$texto= "Aprender a programar" ;
$texto.= " es genial";
echo $texto ;

//Ej 6 

$valor1 =25;
$valor2 =" 25";

var_dump($valor1==$valor2); 
var_dump($valor1===$valor2); 

//Ej 7

$edad=18;

var_dump($edad>=18);

