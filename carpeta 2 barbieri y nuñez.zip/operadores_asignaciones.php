<?php

//Ej 1
$numero=5;
$numero+=5;

echo $numero ;

//Ej 2
$numero=5;
$numero-=5;

echo $numero ;

//Ej 3
$numero=5;
$numero*=5;

echo $numero ;

//Ej 4
$numero=5;
$numero/=5;

echo $numero ;

//Ej 5
$numero=5;
$numero+=5;

echo $numero ;

//Ej 6
$numero="texto de prueba ";
$numero.=2;

echo $numero ;

//Ej 7
$numero=" texto de prueba ";
$numero.="Otro texto más";

echo $numero ;



