<?php

//Mi primer hoooola gente
echo "hoooola gente 1";

//Mi segundo hoooola gente
echo "hoooola gente 2";

/** /Mi tercer 
 * hoooola gente
echo "hoooola gente 3";


