<?php

$num= 2;

    if ($num>=50){
        $num=$num*2 ;
        $num.=2 ;
    } 
?>

        

