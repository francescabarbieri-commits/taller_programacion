<?php

$productos =array("1/2k de frutillas", "1/2k de calabaza", "1/4k de tomate", "1/4k de pepino", "1k de papa");
echo $productos[1] ;
