<?php

$argentina = 3; $argelia = 0;
$austria = 3; $jordania = 1;  
$argentina = 2; $austria = 0;  
$argelia = 2; $jordania = 1;  
$jordania = 0; $argentina = 0;
$argelia = 0; $austria = 0;  

$p_argentina = $argentina + 4;
$p_austria = $austria;
$p_argelia = $argelia + 1;
$p_jordania = $jordania;


echo "El puntaje de Argentina es " .$p_argentina;
echo " El puntaje de Austria es " .$p_austria;
echo " El puntaje de Argelia es " .$p_argelia;
echo " El puntaje de Jordania es " .$p_jordania ;

if ($p_argelia >= 4){
    echo " Argelia pasa a 16 ";
} else {
    echo " Argelia no pasa a 16° "; 
}

if ($p_austria >= 4){
    echo " Austria pasa a 16°";
} else {
    echo " Austria no pasa a 16° ";
}

if ($p_argentina >= 4){
    echo " Argentina pasa a 16° ";
} else {
    echo " Argentina no pasa a 16° ";
}

if ($p_jordania >= 4){
    echo " Jordania pasa a 16° ";
} else {
    echo " Jordania no pasa a 16°";
}
?>

