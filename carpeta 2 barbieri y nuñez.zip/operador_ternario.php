<?php

//ej 1

(9>7) ? $total=10*7 : $total=10*5;

echo $total;

//ej 2

$total= (2>7) ?10*7 : 10*5;

echo $total;
