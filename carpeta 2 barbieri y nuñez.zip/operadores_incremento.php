<?php

//Ej 1 - preincremento

$numero= 10;
echo++ $numero;

//Ej 2 - postincremento

$numero= 10 ;
echo $numero++ ;
echo $numero;

//Ej 3 - predecremento


$numero= 10 ;
echo --$numero ;

//Ej 4 - postdecremento

$numero= 10 ;

echo $numero-- ;
echo $numero;

//Ej 5 - preincremento

$numero=10 ;

$resultado= ++ $numero ;
echo $resultado ;

//Ej 6 - postincremento

$numero =10 ;

$resultado = $numero++ ;
echo $numero;

