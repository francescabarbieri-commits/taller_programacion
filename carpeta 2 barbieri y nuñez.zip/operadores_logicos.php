<?php

//ej 1 -and- falso
$valor_1=7;
$valor_2=2;

var_dump($valor_1==7 && 2>3);

//ej 2 -and- verdadero

$valor_1=7;
$valor_2=2;

var_dump($valor_1==7 && 9>3);

//ej 3 -or- verdadero

$valor_1=7;
$valor_2=2;

var_dump($valor_1==7 or 9>3);

//ej 4 -or- falso
$valor_1=7;
$valor_2=2;

var_dump($valor_1==4 or 1>3);

//ej 5 -or- falso

$valor_1=7;
$valor_2=2;

var_dump($valor_1==4 or 1>3 or $valor_2>10);

//ej 6

$valor_1=7;
$valor_2=2;

var_dump(!($valor_1==$valor_2));

//ej 7

$valor_1=7;
$valor_2=2;

$resultado=!($valor_1==$valor_2);

var_dump($resultado);





