<?php
fuction mostrarPares ($numero, $contador);{ 
    if ($numero <= 50){
    echo $numero . "<br>"; 
    mostrarPares ($numero + 2, $contador + 1) ;
    } else
        echo "<br> Total de pares:" . $contador ;
    }
echo mostrarPares (2, 0);

