<?php

#Array de tipo escalar 
$estudiantes=array("Carlos","José","Vanessa","Katy");

#Array de tipo asociativo
$tutor=["nombre"];

