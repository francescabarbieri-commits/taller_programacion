<?php

//ej 1

    if(1>=0){
        echo "Expresión verdadera" ;
}

?>
 