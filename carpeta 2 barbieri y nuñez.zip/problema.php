<?php

$nom= "Mariano";

$trabajos= 10;
$examen=8;
$fixture=4;

$prom= ($trabajos+$examen+$fixture)/3;

if($prom>=6){
    echo "El alumno está aprobado, por lo tanto no irá a diciembre";
}else{
    echo "El alumno está desaprobado, por lo tanto irá a diciembre"; 
}

if($fixture>=4){
    if($fixture<5){
        echo "El alumno irá al Período de Intensificacion";
}else{
    echo "El alumno no podrá rendir en el Período de Intensificacion"; 
}

if($examen>=4<5){
        if($fixture<5){
        echo "El alumno irá al Período de Intensificacion";
{
}else{
    echo "El alumno no podrá rendir en el Período de Intensificacion"; 
}


if($trabajos>=4<5){
    echo "El alumno irá al Período de Intensificacion";
}else{
    echo "El alumno no podrá rendir en el Período de Intensificacion"; 
}

?>
