<?php

array [
    $invitados=
]